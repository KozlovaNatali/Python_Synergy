print('Привет! Это простой калькулятор.', 'Доступные операции: +, -', sep='\n')
symbol = input('Выберите операцию: ')
number1, number2 = float(input('Введите первое число: ')), float(input('Введите второе число: '))
if symbol == '+':
    print(f'Результат: {number1 + number2}')
elif symbol == '-':
    print(f'Результат: {number1 - number2}')
else:
    print('Упс! Кажется вы ввели неверный символ:(')